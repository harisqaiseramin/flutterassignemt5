import 'package:flutter/material.dart';

class HomePage extends StatefulWidget {
  @override
  _HomePageState createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  int _selected = 0;
  int _currentIndex = 0;
  void changeSelected(int index) {
    setState(() {
      _selected = index;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(
          "Ecommerce App UI",
          style: TextStyle(color: Colors.black),
        ),
        centerTitle: true,
        elevation: 0.0,
        backgroundColor: Colors.redAccent,
        actions: <Widget>[
          IconButton(
              icon: Icon(
                Icons.notifications_none,
                color: Colors.black,
              ),
              onPressed: () {}),
          IconButton(
              icon: Icon(
                Icons.send,
                color: Colors.black,
              ),
              onPressed: () {})
        ],
      ),
      drawer: Container(
        width: 360,
        child: Drawer(
          child: ListView(
            children: [
              DrawerHeader(
                decoration: BoxDecoration(
                  image: DecorationImage(
                      image: AssetImage('assets/header.jpg'),
                      fit: BoxFit.cover),
                ),
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Image(
                      image: AssetImage('assets/img1.jpg'),
                      height: 70,
                    ),
                    Text(
                      'Ecommerce app',
                      style: TextStyle(fontSize: 20, color: Colors.white),
                    ),
                    Row(
                      children: [
                        Text(
                          'harisqaiser07@gmail.com',
                          style: TextStyle(fontSize: 20, color: Colors.white),
                        ),
                        Icon(
                          Icons.arrow_drop_down,
                          color: Colors.white,
                          size: 25,
                        ),
                      ],
                    )
                  ],
                ),
              ),
              ListTile(
                selected: _selected == 0,
                leading: Icon(
                  Icons.folder,
                  size: 28,
                ),
                title: Text(
                  'My Files',
                  style: TextStyle(fontSize: 23),
                ),
                onTap: () {
                  changeSelected(0);
                },
              ),
              ListTile(
                selected: _selected == 1,
                leading: Icon(
                  Icons.share,
                  size: 28,
                ),
                title: Text(
                  'Share',
                  style: TextStyle(fontSize: 23),
                ),
                onTap: () {
                  changeSelected(1);
                },
              ),
              ListTile(
                selected: _selected == 2,
                leading: Icon(
                  Icons.star,
                  size: 28,
                ),
                title: Text(
                  'Starred',
                  style: TextStyle(fontSize: 23),
                ),
                onTap: () {
                  changeSelected(2);
                },
              ),
              new Divider(
                thickness: 3,
                indent: 10,
                endIndent: 10,
              ),
              ListTile(
                selected: _selected == 3,
                leading: Icon(
                  Icons.upload_file,
                  size: 28,
                ),
                title: Text(
                  'Upload',
                  style: TextStyle(fontSize: 23),
                ),
                onTap: () {
                  changeSelected(3);
                },
              ),
              ListTile(
                selected: _selected == 4,
                leading: Icon(
                  Icons.settings,
                  size: 28,
                ),
                title: Text(
                  'Setting',
                  style: TextStyle(fontSize: 23),
                ),
                onTap: () {
                  changeSelected(4);
                },
              ),
              new Divider(
                thickness: 3,
                indent: 10,
                endIndent: 10,
              ),
              ListTile(
                selected: _selected == 5,
                leading: Icon(
                  Icons.info,
                  size: 28,
                ),
                title: Text(
                  'About',
                  style: TextStyle(fontSize: 23),
                ),
                onTap: () {
                  changeSelected(5);
                },
              ),
            ],
          ),
        ),
      ),
      body: SingleChildScrollView(
        child: Column(
          children: [
            Container(
              child: Row(
                children: [
                  Container(
                    width: 120,
                    height: 120,
                    color: Colors.red,
                    child: Image.asset(
                      "assets/3.jpg",
                      width: 100,
                      height: 130,
                      fit: BoxFit.contain,
                    ),
                  ),
                  SizedBox(
                    width: 10,
                  ),
                  Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        "Iphone 12",
                        style: TextStyle(
                            fontSize: 15,
                            fontWeight: FontWeight.bold,
                            height: 2.3),
                      ),
                      Text(
                        '⭐ 5.0(23 Reviews)',
                        style: TextStyle(height: 2.3),
                      ),
                      Row(
                        children: [
                          Text(
                            "20 Pieces ",
                            style: TextStyle(height: 2.3),
                          ),
                          Text(
                            '\$ 90',
                            style: TextStyle(
                                fontSize: 18,
                                color: Colors.purple,
                                fontWeight: FontWeight.bold),
                          ),
                        ],
                      ),
                      Text("Quanlity: 1"),
                    ],
                  ),
                ],
              ),
            ),
            SizedBox(
              height: 20,
            ),
            Container(
              child: Row(
                children: [
                  Container(
                    width: 120,
                    height: 120,
                    color: Colors.grey[100],
                    child: Image.asset("assets/5.jpg",
                        width: 100, height: 130, fit: BoxFit.contain),
                  ),
                  SizedBox(
                    width: 10,
                  ),
                  Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        "Note 20 Ultra",
                        style: TextStyle(
                            fontSize: 15,
                            fontWeight: FontWeight.bold,
                            height: 2.3),
                      ),
                      Text(
                        '⭐ 5.0(23 Reviews)',
                        style: TextStyle(height: 2.3),
                      ),
                      Row(
                        children: [
                          Text(
                            "20 Pieces ",
                            style: TextStyle(height: 2.3),
                          ),
                          Text(
                            '\$ 90',
                            style: TextStyle(
                                fontSize: 18,
                                color: Colors.purple,
                                fontWeight: FontWeight.bold),
                          ),
                        ],
                      ),
                      Text("Quanlity: 1"),
                    ],
                  )
                ],
              ),
            ),
            SizedBox(
              height: 20,
            ),
            Container(
              child: Row(
                children: [
                  Container(
                    width: 120,
                    height: 120,
                    color: Colors.black,
                    child: Image.asset("assets/7.jpg",
                        width: 100, height: 180, fit: BoxFit.contain),
                  ),
                  SizedBox(
                    width: 10,
                  ),
                  Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        "Mackbook Air",
                        style: TextStyle(
                            fontSize: 15,
                            fontWeight: FontWeight.bold,
                            height: 2.3),
                      ),
                      Text(
                        '⭐ 5.0(23 Reviews)',
                        style: TextStyle(height: 2.3),
                      ),
                      Row(
                        children: [
                          Text(
                            "20 Pieces ",
                            style: TextStyle(height: 2.3),
                          ),
                          Text(
                            '\$ 90',
                            style: TextStyle(
                                fontSize: 18,
                                color: Colors.purple,
                                fontWeight: FontWeight.bold),
                          ),
                        ],
                      ),
                      Text("Quanlity: 1"),
                    ],
                  )
                ],
              ),
            ),
            SizedBox(height: 20),
            Container(
              child: Row(
                children: [
                  Container(
                    width: 120,
                    height: 120,
                    color: Colors.grey,
                    child: Image.asset("assets/6.jpg",
                        width: 100, height: 180, fit: BoxFit.contain),
                  ),
                  SizedBox(
                    width: 10,
                  ),
                  Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        "Mackbook Pro",
                        style: TextStyle(
                            fontSize: 15,
                            fontWeight: FontWeight.bold,
                            height: 2.3),
                      ),
                      Text(
                        '⭐ 5.0(23 Reviews)',
                        style: TextStyle(height: 2.3),
                      ),
                      Row(
                        children: [
                          Text(
                            "20 Pieces ",
                            style: TextStyle(height: 2.3),
                          ),
                          Text(
                            '\$ 90',
                            style: TextStyle(
                                fontSize: 18,
                                color: Colors.purple,
                                fontWeight: FontWeight.bold),
                          ),
                        ],
                      ),
                      Text("Quanlity: 1"),
                    ],
                  )
                ],
              ),
            ),
            SizedBox(
              height: 20,
            ),
            Container(
              child: Row(
                children: [
                  Container(
                    width: 120,
                    height: 120,
                    color: Colors.blue,
                    child: Image.asset("assets/8.jpg",
                        width: 100, height: 180, fit: BoxFit.contain),
                  ),
                  SizedBox(
                    width: 10,
                  ),
                  Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        "Gaming PC",
                        style: TextStyle(
                            fontSize: 15,
                            fontWeight: FontWeight.bold,
                            height: 2.3),
                      ),
                      Text(
                        '⭐ 5.0(23 Reviews)',
                        style: TextStyle(height: 2.3),
                      ),
                      Row(
                        children: [
                          Text(
                            "20 Pieces ",
                            style: TextStyle(height: 2.3),
                          ),
                          Text(
                            '\$ 90',
                            style: TextStyle(
                                fontSize: 18,
                                color: Colors.purple,
                                fontWeight: FontWeight.bold),
                          ),
                        ],
                      ),
                      Text("Quanlity: 1"),
                    ],
                  )
                ],
              ),
            )
          ],
        ),
      ),
      bottomNavigationBar: BottomNavigationBar(
        currentIndex: _currentIndex,
        backgroundColor: Colors.red,
        type: BottomNavigationBarType.fixed,
        items: [
          BottomNavigationBarItem(
              icon: Icon(Icons.home),
              title: Text('Home'),
              backgroundColor: Colors.blue),
          BottomNavigationBarItem(
              icon: Icon(Icons.search),
              title: Text('Search'),
              backgroundColor: Colors.yellow),
          BottomNavigationBarItem(
              icon: Icon(Icons.camera),
              title: Text('Camera'),
              backgroundColor: Colors.green),
          BottomNavigationBarItem(
              icon: Icon(Icons.person),
              title: Text('Profile'),
              backgroundColor: Colors.green),
        ],
      ),
    );
  }
}
