import 'package:flutter/material.dart';
import 'package:secondproject/signuppage.dart';
import 'package:secondproject/homepage.dart';
import 'package:secondproject/splash.dart';
import 'package:secondproject/loginpage.dart';

void main() {
  runApp(myapp());
}

class myapp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
        title: 'Rehmania Institute',
        debugShowCheckedModeBanner: false,
        theme: ThemeData(
          primarySwatch: Colors.grey,
        ),
        home: Splash(),
        routes: <String, WidgetBuilder>{
          '/landingpage': (BuildContext context) => myapp(),
          '/loginpage': (BuildContext context) => Loginpage(),
          '/signuppage': (BuildContext context) => SignUp(),
          '/homepage': (BuildContext context) => HomePage()
        });
  }
}
